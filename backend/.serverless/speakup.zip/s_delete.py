import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='caseykey',
    application_name='speakup-app',
    app_uid='g4hv7KfjwyQXXlMZZk',
    org_uid='XKng4579F1Z9TdtXZ2',
    deployment_uid='bb3d8d43-3203-4768-9045-ad15e590ee58',
    service_name='speakup',
    stage_name='dev',
    plugin_version='3.4.0'
)
handler_wrapper_kwargs = {'function_name': 'speakup-dev-delete', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('item/delete.delete')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
